fetch("create_order.php", {
  method: "POST",
  headers: { "Content-Type": "application/x-www-form-urlencoded" },
  body: "amount=109.98"
})
.then(res => res.json())
.then(data => {
  var options = {
    key: "rzp_test_YourKeyId",
    amount: 10998,
    currency: "INR",
    name: "Aurellia",
    description: "Product Purchase",
    order_id: data.order_id,
    handler: function (response) {
      alert("Payment Successful!");
    }
  };
  var rzp = new Razorpay(options);
  rzp.open();
});
