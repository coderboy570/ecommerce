<?php
session_start();
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_SESSION['user'] ?? 'Guest';
$cart = $_SESSION['cart'] ?? [];
$total = $_SESSION['cart_total'] ?? 0;

// Example values – ideally fetch from user profile or form
$email = "test@example.com";
$address = "Default Address";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cart - Aurellia</title>
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: #fff;
      padding: 1rem 2rem;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    header h1 {
      color: #007bff;
      font-size: 1.8rem;
    }
    .user-info {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .user-info img {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #007bff;
    }
    .user-info span {
      font-weight: bold;
      color: #333;
    }
    .user-info a {
      color: #dc3545;
      text-decoration: none;
      margin-left: 1rem;
    }
    .cart-container {
      max-width: 1100px;
      margin: 2rem auto;
      background: white;
      border-radius: 12px;
      padding: 2rem;
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
  <header>
    <h1>Aurellia</h1>
    <div class="user-info">
      <?php if ($user !== 'Guest'): ?>
        <span><?php echo htmlspecialchars($user); ?></span>
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <a href="login.html" style="color:#007bff;">Login</a>
      <?php endif; ?>
    </div>
  </header>

  <div class="cart-container">
    <h2>Welcome, <?php echo htmlspecialchars($user); ?>. Your cart is ready!</h2>

    <?php if ($user !== 'Guest' && !empty($cart)): ?>
      <form action="save_order.php" method="POST">
        <?php foreach ($cart as $index => $item): ?>
          <input type="hidden" name="cart[<?php echo $index; ?>][id]" value="<?php echo htmlspecialchars($item['id']); ?>">
          <input type="hidden" name="cart[<?php echo $index; ?>][name]" value="<?php echo htmlspecialchars($item['name']); ?>">
          <input type="hidden" name="cart[<?php echo $index; ?>][price]" value="<?php echo htmlspecialchars($item['price']); ?>">
          <input type="hidden" name="cart[<?php echo $index; ?>][quantity]" value="<?php echo htmlspecialchars($item['quantity']); ?>">
          <input type="hidden" name="cart[<?php echo $index; ?>][img]" value="<?php echo htmlspecialchars($item['img']); ?>">
        <?php endforeach; ?>

        <input type="hidden" name="name" value="<?php echo htmlspecialchars($user); ?>">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
        <input type="hidden" name="address" value="<?php echo htmlspecialchars($address); ?>">
        <input type="hidden" name="total" value="<?php echo htmlspecialchars($total); ?>">

        <button type="submit">Submit Order</button>
      </form>
    <?php elseif ($user === 'Guest'): ?>
      <button class="btn btn-secondary" disabled>Submit Order</button>
      <p style="color: red; margin-top: 10px;">Please login to place an order.</p>
    <?php else: ?>
      <p>Your cart is empty.</p>
    <?php endif; ?>
  </div>
</body>
</html>
z