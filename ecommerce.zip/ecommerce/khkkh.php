khkkh

$prod_id1=$_POST["product_id"];
$prod_id2=$_POST["product_id"];
$sql="SELECT * FROM $tablename WHERE $prod_id1=$prod_id2";
$records=mysqli_query($connect2, $sql);
while($rows=mysqli_fetch_array($records))
{
echo "Product Id=".$rows['product_id']."</br>";
echo "Name=".$rows['product_name']."</br>";
echo "Brand=".$rows['product_brand']."</br>";
echo "Quantity=".$rows['product_quantity']."</br>";
echo "Price=".$rows['product_price']."</br>";
}
echo "Product Avalaible"."</br>";