<?php
session_start();

$username = $_POST['username'];
$password = $_POST['password'];
$mobile = $_POST['mobile'];
$photo = $_FILES['photo'];

$targetDir = "uploads/";
if (!is_dir($targetDir)) {
    mkdir($targetDir);
}

$photoName = basename($photo['name']);
$targetFile = $targetDir . $photoName;

if (move_uploaded_file($photo['tmp_name'], $targetFile)) {
    $file = fopen("user_credentials.csv", "a");
    if ($file) {
        fputcsv($file, [$username, $password, $mobile, $photoName]);
        fclose($file);

        $_SESSION['user'] = $username;
        $_SESSION['photo'] = $photoName;

        header("Location: index.html");
        exit();
    } else {
        echo "Failed to write to CSV file.";
    }
} else {
    echo "Failed to upload photo.";
}
?>
