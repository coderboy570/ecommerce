<?php
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];

// Prevent duplicates
$check = $conn->prepare("SELECT id FROM newsletter WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "<script>alert('You are already subscribed.'); window.location.href='contact.html';</script>";
} else {
    $stmt = $conn->prepare("INSERT INTO newsletter (email) VALUES (?)");
    $stmt->bind_param("s", $email);
    if ($stmt->execute()) {
        echo "<script>alert('Thanks for subscribing!'); window.location.href='contact.html';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$check->close();
$conn->close();
?>
