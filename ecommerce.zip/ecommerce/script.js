// Wait until the document is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    loadCartItems();
    setupCartActions();
});

// Select all "Add to Cart" buttons and enable functionality
document.querySelectorAll(".cart").forEach(button => {
    button.addEventListener("click", (event) => {
        let productElement = event.target.closest(".pro");
        let product = {
            image: productElement.querySelector("img").src,
            name: productElement.querySelector(".des h5").innerText,
            price: productElement.querySelector(".des h4").innerText.replace("₹", ""),
            quantity: 1
        };
        addToCart(product);
    });
});

// Function to add product to the cart
function addToCart(product) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    
    let existingProduct = cart.find(item => item.name === product.name);
    if (existingProduct) {
        existingProduct.quantity++;
    } else {
        cart.push(product);
    }

    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Product added to cart!");
}

// Load cart items from localStorage on cart.html
function loadCartItems() {
    let cartTableBody = document.querySelector("#cart tbody");
    if (!cartTableBody) return;

    cartTableBody.innerHTML = ""; // Clear existing rows
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    cart.forEach(product => {
        let row = document.createElement("tr");
        row.innerHTML = `
            <td><a href="#" class="remove"><i class="far fa-times-circle"></i></a></td>
            <td><img src="${product.image}" alt=""></td>
            <td>${product.name}</td>
            <td>₹${product.price}</td>
            <td><input type="number" value="${product.quantity}" min="1"></td>
            <td>₹${product.price * product.quantity}</td>
        `;
        cartTableBody.appendChild(row);
    });

    updateTotal();
}

// Update cart total dynamically
function updateTotal() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = cart.reduce((sum, product) => sum + product.price * product.quantity, 0);
    
    document.querySelector("#subtotal table tr:nth-child(1) td:nth-child(2)").innerText = ₹ ${total};
    document.querySelector("#subtotal table tr:nth-child(3) td:nth-child(2)").innerText = ₹ ${total};
}

// Setup event listeners for cart actions (removal, quantity change)
function setupCartActions() {
    document.querySelector("#cart tbody")?.addEventListener("click", (event) => {
        if (event.target.closest(".remove")) {
            let row = event.target.closest("tr");
            let productName = row.children[2].innerText;
            removeFromCart(productName);
            row.remove();
            updateTotal();
        }
    });

    document.querySelector("#cart tbody")?.addEventListener("change", (event) => {
        if (event.target.tagName === "INPUT") {
            let row = event.target.closest("tr");
            let productName = row.children[2].innerText;
            let newQuantity = parseInt(event.target.value);
            updateQuantity(productName, newQuantity);
            row.children[5].innerText = ₹${newQuantity * row.children[3].innerText.replace("₹", "")};
            updateTotal();
        }
    });
}

// Remove an item from cart
function removeFromCart(productName) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart = cart.filter(product => product.name !== productName);
    localStorage.setItem("cart", JSON.stringify(cart));
}

// Update product quantity in cart
function updateQuantity(productName, quantity) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let product = cart.find(item => item.name === productName);
    if (product) {
        product.quantity = quantity;
        localStorage.setItem("cart", JSON.stringify(cart));
    }
}