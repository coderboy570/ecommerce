<html>
    <head>
        This is email confirmation
    </head>
    <body>
        <h1><b><i>Your Email is confirmed get the hell out of here</i></b></h1>
    </body>
    </html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the form
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }
    
    // Define the CSV file path
    $file = 'emails.csv';
    
    // Check if the file exists
    $isNewFile = !file_exists($file);
    
    // Open the file for appending
    $handle = fopen($file, 'a');
    
    if ($isNewFile) {
        // If the file is new, add a header row
        fputcsv($handle, ['Email']);
    }
    
    // Add the new email
    fputcsv($handle, [$email]);
    
    // Close the file
    fclose($handle);
    
    echo "Thank you for subscribing!";
} else {
    echo "Invalid request.";
}
?>
