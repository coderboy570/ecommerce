 <?php
session_start();

$amount = isset($_SESSION['amount']) ? $_SESSION['amount'] : 0;
echo json_encode(['amount' => $amount]);

