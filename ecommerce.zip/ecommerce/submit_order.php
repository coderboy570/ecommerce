<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user'] == 'Guest') {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_SESSION['user'];
$cart = $_SESSION['cart'] ?? [];
$total = $_SESSION['cart_total'] ?? 0;  // Or calculate manually
$date = date("Y-m-d H:i:s");

// Loop through cart
foreach ($cart as $item) {
    $stmt = $conn->prepare("INSERT INTO orders (username, product_id, product_name, price, quantity, image_url, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "sssdisd",
        $user,
        $item['id'],
        $item['name'],
        $item['price'],
        $item['quantity'],
        $item['img'],
        $date
    );
    $stmt->execute();
    $stmt->close();
}

// ✅ Set total securely before going to payment
$_SESSION['cart_total'] = $total;

$conn->close();

// ⛳ Now go to payment
header("Location: payment.html");
exit();
