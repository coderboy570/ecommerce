<?php
session_start(); // 🔹 Start the session

// 1. Connect to database
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt password

// 3. Save to database
$sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $name, $email, $password);

if ($stmt->execute()) {
    // ✅ Set session and redirect to index.html
    $_SESSION['user'] = $name;
    $_SESSION['user_id'] = $stmt->insert_id;
    header("Location: index.html");
    exit();
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
