<?php
require('vendor/autoload.php');
use Razorpay\Api\Api;

$api = new Api("rzp_test_2dXUELtZFAlazD", "DM3wzrzl2KCMGI9RzAH2AOSa");

$amount_rupees = $_POST['amount']; // e.g., 80.97
$amount_paise = round(floatval($amount_rupees) * 100); // Razorpay needs paise

$orderData = [
  'receipt' => 'rcpt_' . time(),
  'amount' => $amount_paise,
  'currency' => 'INR',
  'payment_capture' => 1
];

$order = $api->order->create($orderData);

// Return order ID and amount to frontend
echo json_encode([
  'order_id' => $order['id'],
  'amount' => $amount_paise
]);
