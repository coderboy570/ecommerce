<?php
// Connect to MySQL
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Insert into messages table
$stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $subject, $message);

if ($stmt->execute()) {
    echo "<script>alert('✅ Message sent successfully!'); window.location.href='contact.html';</script>";
} else {
    echo "<script>alert('❌ Failed to send message.'); window.location.href='contact.html';</script>";
}

$stmt->close();
$conn->close();
?>
