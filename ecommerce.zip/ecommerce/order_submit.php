<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['fullname'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $orderData = json_decode($_POST['orderData'], true);

    $file = fopen("orders.csv", "a");

    foreach ($orderData as $item) {
        fputcsv($file, [
            date("Y-m-d H:i:s"),
            $name,
            $email,
            $address,
            $item['name'],
            $item['quantity'],
            $item['price'],
            $item['price'] * $item['quantity']
        ]);
    }

    fclose($file);

    echo "<h2>Thank you for your order, $name!</h2>";
    echo "<p>We’ve saved your order and will ship to: $address</p>";
}
?>
