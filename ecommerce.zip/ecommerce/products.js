// products.js

const products = {
  p1: { name: "Astronaut Graphic Tee", price: 19.99, img: "img2.jpg" },
  p2: { name: "Floral Casual Shirt", price: 24.99, img: "img3.jpg" },
  p3: { name: "Vintage Bloom Shirt", price: 26.99, img: "img4.jpg" },
  p4: { name: "Knitted Green Sweater", price: 399, img: "img5.jpg" },
  p5: { name: "Urban Street Sneakers", price: 59.99, img: "modern-sneakers.jpg" },
  p6: { name: "Elegant Red Dress", price: 49.99, img: "fashion-women.jpg" },
  p7: { name: "Premium Men's Blazer", price: 89.99, img: "mens-style.jpg" },
  p8: { name: "Casual Bomber Jacket", price: 69.99, img: "casual-jacket.jpg" },
  p9: { name: "Designer Sunglasses", price: 200, img: "sunglasses.jpeg" },
  p10: { name: "White Casual Knit Tee", price: 21.99, img: "img1.jpg" },
  p11: { name: "Classic Black Jacket", price: 54.99, img: "img11.jpg" },
  p12: { name: "Dark Check Shirt", price: 29.99, img: "img13.jpg" },
  p13: { name: "Olive Green Slim Shirt", price: 27.5, img: "img15.jpg" },
  p14: { name: "Light Blue Mandarin Shirt", price: 26.00, img: "img18.jpg" },
  p15: { name: "Yellow Plaid Casual Shirt", price: 25.99, img: "img19.jpg" },
  p16: { name: "Brown Short Sleeve Check", price: 23.50, img: "img20.jpg" },
  p17: { name: "Green Graphic Tee", price: 22.00, img: "img21.jpg" },
  p18: { name: "Sleeveless Sports Tee", price: 19.99, img: "img33.jpg" }
  

};
