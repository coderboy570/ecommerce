// Payment logic here...

// If payment is successful:
header("Location: thank-you.html");
exit();
