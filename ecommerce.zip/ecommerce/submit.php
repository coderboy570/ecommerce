 
<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get email from POST request
$email = $_POST['email'] ?? '';

if (!empty($email)) {
    // Insert into database
    $stmt = $conn->prepare("INSERT INTO newsletter_subscribers (email) VALUES (?)");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        echo "<script>alert('Thank you for subscribing!'); window.location.href = 'index.html';</script>";
    } else {
        echo "<script>alert('You may have already subscribed or an error occurred.'); window.location.href = 'index.html';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Please enter a valid email.'); window.location.href = 'index.html';</script>";
}

$conn->close();
?>
