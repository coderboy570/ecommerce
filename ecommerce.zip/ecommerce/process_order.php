<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_decode(file_get_contents('php://input'), true);

  $name = $data['fullname'] ?? '';
  $email = $data['email'] ?? '';
  $address = $data['address'] ?? '';
  $cart = json_encode($data['cart'] ?? []);
  $method = $data['method'] ?? 'unknown';

  $orderDetails = "Name: $name\nEmail: $email\nAddress: $address\nPayment Method: $method\nCart: $cart\n------------------------\n";

  // Save to file (or database if desired)
  file_put_contents("orders.txt", $orderDetails, FILE_APPEND);

  echo json_encode(["status" => "success", "message" => "Order saved successfully."]);
} else {
  echo json_encode(["status" => "error", "message" => "Invalid request."]);
}
?>
