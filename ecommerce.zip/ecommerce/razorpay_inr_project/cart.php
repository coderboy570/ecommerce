<?php
session_start();
$total = 80.97; // Simulated total
?>
<!DOCTYPE html>
<html>
<head><title>Cart</title></head>
<body>
  <h2>Your Cart</h2>
  <p>Total: ₹<?php echo $total; ?></p>
  <form action="save_order.php" method="POST">
    <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
    <button type="submit">Submit Order</button>
  </form>
</body>
</html>
