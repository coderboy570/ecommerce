const products = [
  {
    id: 1,
    name: "Grey Jeans for Men",
    price: 1500,
    img: "img38.jpg",
    brand: "adidas",
    description: "Comfortable slim fit denim jeans for everyday wear."
  },
  {
    id: 2,
    name: "Men's Loose Hoodie",
    price: 1200,
    img: "img39.jpg",
    brand: "adidas",
    description: "Casual hoodie for comfort and style."
  },
  {
    id: 3,
    name: "Polo Shirt for Men",
    price: 1000,
    img: "img40.jpg",
    brand: "H&M",
    description: "Classic pique polo shirt in regular fit."
  },
  {
    id: 4,
    name: "Black Sweatshirt",
    price: 1399,
    img: "img41.jpg",
    brand: "H&M",
    description: "Warm and stylish oversized sweatshirt."
  },
  {
    id: 5,
    name: "Basic Black T-shirt",
    price: 699,
    img: "img42.jpg",
    brand: "H&M",
    description: "Everyday essential T-shirt in soft cotton."
  },
  {
    id: 6,
    name: "Sky Blue Tunic Dress",
    price: 1799,
    img: "img43.jpg",
    brand: "& Other Stories",
    description: "Lightweight tunic dress for relaxed days."
  },
  {
    id: 7,
    name: "Black Cropped Polo",
    price: 899,
    img: "img44.jpg",
    brand: "Cotton On",
    description: "Trendy cropped polo top in stretch cotton."
  },
  {
    id: 8,
    name: "Blue Knit Cardigan",
    price: 1599,
    img: "img45.jpg",
    brand: "& Other Stories",
    description: "Cozy chunky knit cardigan with buttons."
  }
];
