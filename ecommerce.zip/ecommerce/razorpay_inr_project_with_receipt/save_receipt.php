<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aurellia_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get payment data
$payment_id = $_POST['payment_id'];
$amount = $_POST['amount'];

// Insert into receipts table
$stmt = $conn->prepare("INSERT INTO payment_receipts (payment_id, amount) VALUES (?, ?)");
$stmt->bind_param("sd", $payment_id, $amount);

if ($stmt->execute()) {
  echo "Receipt saved.";
} else {
  echo "Error: " . $stmt->error;
}
$stmt->close();
$conn->close();
?>
