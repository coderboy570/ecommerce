<?php
session_start();
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_SESSION['user'] ?? 'Guest';

$cart = $_POST['cart'];
$name = $_POST['name'];
$email = $_POST['email'];
$address = $_POST['address'];
$total = $_POST['total'];
$date = date("Y-m-d H:i:s");

foreach ($cart as $item) {
    $stmt = $conn->prepare("INSERT INTO orders (username, product_id, product_name, price, quantity, image_url, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "sssdisd",
        $user,
        $item['id'],
        $item['name'],
        $item['price'],
        $item['quantity'],
        $item['img'],
        $date
    );
    $stmt->execute();
    $stmt->close();
}

echo "<script>alert('✅ Order saved successfully!'); window.location.href = 'payment.html';</script>";
$conn->close();
?>
