file_put_contents("debug.txt", print_r($_POST, true));
<?php
session_start();

ini_set('display_errors', 1); // 👈 Shows PHP errors
error_reporting(E_ALL);

$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("❌ DB Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['user'] ?? 'Guest';
$payment_id = $_POST['payment_id'] ?? '';
$order_id = $_POST['order_id'] ?? '';
$signature = $_POST['signature'] ?? '';
$date = date("Y-m-d H:i:s");

// Debug print (for testing only)
if (!$payment_id || !$order_id || !$signature) {
    die("❌ Incomplete data: payment_id=$payment_id, order_id=$order_id, signature=$signature");
}

$stmt = $conn->prepare("INSERT INTO payments (username, razorpay_payment_id, razorpay_order_id, razorpay_signature, date) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    die("❌ Prepare failed: " . $conn->error);
}

$stmt->bind_param("sssss", $username, $payment_id, $order_id, $signature, $date);

if ($stmt->execute()) {
    echo "✅ Payment saved successfully!";
} else {
    echo "❌ Insert failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
