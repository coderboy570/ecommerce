<?php
 session_start();
 $_SESSION['username'] = $username; // Or whatever you're storing
 

$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();

  if (password_verify($password, $user['password'])) {
    $_SESSION['user'] = $user['name'];
    $_SESSION['user_id'] = $user['id'];

    // Save login to database
    $log = $conn->prepare("INSERT INTO login_logs (user_id, email, message) VALUES (?, ?, ?)");
    $msg = "Login successful";
    $log->bind_param("iss", $user['id'], $email, $msg);
    $log->execute();
    $log->close();

    header("Location: index.html"); // redirect to home page
    exit();
  } else {
    echo "<script>alert('❌ Incorrect password.'); window.location.href='login.html';</script>";
  }
} else {
  echo "<script>alert('❌ No account found with this email.'); window.location.href='login.html';</script>";
}

$stmt->close();
$conn->close();
?>
