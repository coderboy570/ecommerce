<?php
session_start();
$user = $_SESSION['user'] ?? null;
?>

<!DOCTYPE html>
<html>
<head>
  <title>Aurellia Home</title>
  <style>
    .top-bar {
      background:rgb(255, 255, 255);
      padding: 1rem 2rem;
      text-align: right;
      font-family: Arial, sans-serif;
    }
    .top-bar span {
      font-weight: bold;
      color: #007bff;
    }
  </style>
</head>
<body>
  <div class="top-bar">
    <?php if ($user): ?>
      Welcome, <span><?php echo htmlspecialchars($user); ?></span> | <a href="logout.php">Logout</a>
    <?php else: ?>
       
    <?php endif; ?>
  </div>
 
</body>
</html>

< 

<div>
  <?php if (isset($_SESSION['user'])): ?>
    Welcome, <strong><?= $_SESSION['user'] ?></strong> |
    <a href="logout.php">Logout</a>
  <?php else: ?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Aurellia E-commerce Site</title>
   <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
   <style>
     * {
       margin: 0;
       padding: 0;
       box-sizing: border-box;
       font-family: 'Inter', sans-serif;
     }
     body {
       background-color: #f8f9fa;
       color: #333;
     }
     #header {
       display: flex;
       justify-content: space-between;
       align-items: center;
       padding: 1rem 2rem;
       background-color: #fff;
       box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
       position: sticky;
       top: 0;
       z-index: 100;
     }
     #navbar {
       list-style: none;
       display: flex;
       gap: 1.5rem;
     }
     #navbar li a {
       text-decoration: none;
       color: #333;
       font-weight: 500;
     }
     #navbar li a.active, #navbar li a:hover {
       color: #007bff;
     }
     #hero {
       background: linear-gradient(to right, #dee2ff, #edf2fb);
       padding: 3rem;
       text-align: center;
     }
     #hero h1 {
       font-size: 2.5rem;
       color: #212529;
     }
     #hero h4, #hero h2, #hero p {
       margin-bottom: 0.5rem;
     }
     #hero button {
       background-color: #007bff;
       color: #fff;
       border: none;
       padding: 0.75rem 1.5rem;
       border-radius: 5px;
       cursor: pointer;
       transition: background 0.3s;
     }
     #hero button:hover {
       background-color: #0056b3;
     }
     #products {
       padding: 2rem;
       max-width: 1200px;
       margin: auto;
     }
     #products h2 {
       text-align: center;
       margin-bottom: 2rem;
     }
     .product {
       border: 1px solid #ddd;
       border-radius: 10px;
       padding: 1rem;
       margin: 1rem;
       text-align: center;
       background-color: #fff;
       box-shadow: 0 2px 10px rgba(0,0,0,0.05);
       transition: transform 0.2s;
       display: inline-block;
       width: 250px;
     }
     .product:hover {
       transform: translateY(-5px);
     }
     .product img {
       width: 100%;
       height: 220px;
       object-fit: cover;
       border-radius: 5px;
     }
     .product h3 {
       margin-top: 0.75rem;
       font-size: 1.1rem;
     }
     .product p {
       font-weight: bold;
       color: #28a745;
     }
     .product button {
       margin-top: 0.5rem;
       padding: 0.5rem 1rem;
       background-color: #28a745;
       color: #fff;
       border: none;
       border-radius: 5px;
       cursor: pointer;
       transition: background 0.3s;
     }
     .product button:hover {
       background-color: #218838;
     }
     .cart-count {
       background: red;
       color: white;
       border-radius: 50%;
       padding: 2px 6px;
       font-size: 0.75rem;
       position: absolute;
       top: -8px;
       right: -10px;
     }
   </style>
</head>

<body>
  <section id="header">
    <img src="logo4-.png" class="logo" alt="">
    <div>
      <ul id="navbar">
        
        <li><a class="active" href="ecommerce(1).html">Home</a></li>
        <li><a href="shop.html">Shop</a></li>
        <li><a href="blog.html">Blog</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="contact.html">Contact</a></li>
        <li><a href="register.html">Account</a></li>
        <li><a href="login.html"><i class="far fa-user"></i> Login</a></li>


        <li style="position: relative;">
          <a href="cart.html">
            <i class="far fa-shopping-bag"></i><span id="cart-count" class="cart-count">0</span></a>
        </li>
      </ul>
    </div>
  </section>
  <section id="hero" style="
  background: url('img47.jpg') no-repeat center center/cover;
  padding: 5rem 2rem;
  color: white;
  text-align: center;
  position: relative;
">
  <div style="background-color: rgba(0, 0, 0, 0.6); padding: 2rem; border-radius: 8px; display: inline-block;">
    <h4>Trade-in-offer</h4>
    <h2 style="font-size: 2.5rem;">Super Value Deals</h2>
    <h1 style="font-size: 3rem; font-weight: bold;">On All Products</h1>
    <p style="font-size: 1.2rem; margin-bottom: 1rem;">Save more with coupons & up to 70% off!</p>
    <button style="padding: 0.75rem 1.5rem; font-size: 1rem; background-color: #28a745; border: none; color: white; border-radius: 5px; cursor: pointer;">Shop Now</button>
  </div>
</section>

  <section id="hero">
    <h4>Trade-in-offer</h4>
    <h2>Super Value Deals</h2>
    <h1>On all products</h1>
    <p>Save more with coupons & up to 70% off!</p>
    <button onclick="location.href='shop.html'">Shop Now</button>
  </section>

  <section id="products">
    <h2>Featured Products</h2>
    <div style="display: flex; flex-wrap: wrap; justify-content: center;">
      <div class="product" id="p1">
        <a href="product.html?id=p1" style="text-decoration: none; color: inherit;">
          <img src="img2.jpg" alt="Astronaut Tee">
          <h3 class="product-name">Astronaut Graphic Tee</h3>
          <p>₹10</p>
        </a>
        <button onclick="addToCart('p1', products['p1'].name, products['p1'].price)">Add to Cart</button>
      </div>
      
      
      </a>
      
      <a href="product.html?id=p1" style="text-decoration: none; color: inherit;">
        <div class="product" id="p2">
          <a href="product.html?id=p2" style="text-decoration: none; color: inherit;">
            <img src="img3.jpg" alt="Floral Shirt">
            <h3 class="product-name">Floral Casual Shirt</h3>
            <p>$24.99</p>
          </a>
          <button onclick="addToCart('p2', products['p2'].name, products['p2'].price)">Add to Cart</button>
        </div>
        
      </a>
      
      <a href="product.html?id=p1" style="text-decoration: none; color: inherit;">
        <div class="product" id="p3">
          <a href="product.html?id=p3" style="text-decoration: none; color: inherit;">
            <img src="img4.jpg" alt="Vintage Shirt">
            <h3 class="product-name">Vintage Bloom Shirt</h3>
            <p>$26.99</p>
          </a>
          <button onclick="addToCart('p3', products['p3'].name, products['p3'].price)">Add to Cart</button>
        </div>
        
      </a>
      
      <a href="product.html?id=p4" style="text-decoration: none; color: inherit;">
        <div class="product" id="p3">
          <a href="product.html?id=p4" style="text-decoration: none; color: inherit;">
            <img src="img5.jpg" alt="Vintage Shirt">
            <h3 class="product-name">Vintage Bloom Shirt</h3>
            <p>$26.99</p>
          </a>
          <button onclick="addToCart('p4', products['p4'].name, products['p4'].price)">Add to Cart</button>
        </div>
        
      </a>
        <button onclick="addToCart('p4', 'Knitted Green Sweater', 399)">Add to Cart</button>
      </div>
    </div>
  </section>

  <script>
    const cart = JSON.parse(localStorage.getItem("cart")) || [];

    function addToCart(id, name, price) {
      const index = cart.findIndex(item => item.id === id);
      if (index !== -1) {
        cart[index].quantity += 1;
      } else {
        cart.push({ id, name, price, quantity: 1 });
      }
      localStorage.setItem("cart", JSON.stringify(cart));
      alert(`${name} added to cart!`);
      updateCartCount();
    }

    function updateCartCount() {
      const count = cart.reduce((acc, item) => acc + item.quantity, 0);
      document.getElementById("cart-count").innerText = count;
    }

    document.addEventListener("DOMContentLoaded", updateCartCount);
  </script>
  <script src="products.js"></script>

</body>

<section id="trending">
    <h2 style="text-align:center; margin-top: 3rem;">Trending Now</h2>
    <div style="display: flex; flex-wrap: wrap; justify-content: center;">
      <a href="product.html?id=p5" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="modern-sneakers.jpg" alt="Sneakers">
        <h3>Urban Street Sneakers</h3>
        <p>$59.99</p>
        <button onclick="addToCart('p5', 'Urban Street Sneakers', 59.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p6" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="fashion-women.jpg" alt="Red Dress">
        <h3>Elegant Red Dress</h3>
        <p>$49.99</p>
        <button onclick="addToCart('p6', 'Elegant Red Dress', 49.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p7" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="mens-style.jpg" alt="Blazer">
        <h3>Premium Men's Blazer</h3>
        <p>$89.99</p>
        <button onclick="addToCart('p7', 'Premium Men\'s Blazer', 89.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p8" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="casual-jacket.jpg" alt="Bomber Jacket">
        <h3>Casual Bomber Jacket</h3>
        <p>$69.99</p>
        <button onclick="addToCart('p8', 'Casual Bomber Jacket', 69.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p9" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="sunglasses.jpeg" alt="Sunglasses">
        <h3>Designer Sunglasses</h3>
        <p>200</p>
        <button onclick="addToCart('p9', 'Designer Sunglasses', 200)">Add to Cart</button>
      </div></a>
    </div>
  </section>
  <section id="latest-arrivals">
    <h2 style="text-align:center; margin-top: 3rem;">Latest Arrivals</h2>
    <div style="display: flex; flex-wrap: wrap; justify-content: center;">
      <a href="product.html?id=p10" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img1.jpg" alt="White Tee">
        <h3>White Casual Knit Tee</h3>
        <p>$21.99</p>
        <button onclick="addToCart('p10', 'White Casual Knit Tee', 21.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p11" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img11.jpg" alt="Black Jacket">
        <h3>Classic Black Jacket</h3>
        <p>$54.99</p>
        <button onclick="addToCart('p11', 'Classic Black Jacket', 54.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p12" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img13.jpg" alt="Check Shirt">
        <h3>Dark Check Shirt</h3>
        <p>$ </p>
        <button onclick="addToCart('p12', 'Dark Check Shirt',  )">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p13" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img15.jpg" alt="Slim Fit">
        <h3>Olive Green Slim Shirt</h3>
        <p>$27.50</p>
        <button onclick="addToCart('p13', 'Olive Green Slim Shirt', 27.50)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p14" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img18.jpg" alt="Mandarin Shirt">
        <h3>Light Blue Mandarin Shirt</h3>
        <p>$26.00</p>
        <button onclick="addToCart('p14', 'Light Blue Mandarin Shirt', 26.00)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p15" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img19.jpg" alt="Yellow Shirt">
        <h3>Yellow Plaid Casual Shirt</h3>
        <p>$25.99</p>
        <button onclick="addToCart('p15', 'Yellow Plaid Casual Shirt', 25.99)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p16" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img20.jpg" alt="Short Sleeve Check">
        <h3>Brown Short Sleeve Check</h3>
        <p>23.50</p>
        <button onclick="addToCart('p16', 'Brown Short Sleeve Check', 23.50)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p17" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img21.jpg" alt="Green Tee">
        <h3>Green Graphic Tee</h3>
        <p>$22.00</p>
        <button onclick="addToCart('p17', 'Green Graphic Tee', 22.00)">Add to Cart</button>
      </div></a>
      <a href="product.html?id=p18" style="text-decoration: none; color: inherit;"><div class="product">
        <img src="img33.jpg" alt="Sports Tee">
        <h3>Sleeveless Sports Tee</h3>
        <p>$19.99</p>
        <button onclick="addToCart('p18', 'Sleeveless Sports Tee', 19.99)">Add to Cart</button>
      </div></a>
    </div>
  </section>
  
  <section style="background: #007bff; color: #fff; padding: 3rem; text-align: center; margin-top: 4rem;">
    <h2>Join Our Newsletter</h2>
    <p>Subscribe to get updates on latest products and exclusive deals</p>
    <form action="submit.php" method="POST">
      <input type="email" name="email" placeholder="Enter your email" required style="padding: 0.5rem; width: 250px; border: none; border-radius: 4px; margin-right: 0.5rem;">
      <button type="submit" style="padding: 0.5rem 1rem; background: #fff; color: #007bff; border: none; border-radius: 4px; cursor: pointer;">Subscribe</button>
    </form>
  </section>
  <section id="account-section" style="padding: 3rem 2rem; background-color: #f8f9fa;">
    <div style="max-width: 1200px; margin: auto;">
      <h2 style="text-align: center; font-size: 2rem; margin-bottom: 2rem;">Your Account</h2>
      <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 2rem;">
        <div style="background: white; padding: 1.5rem; border-radius: 10px; width: 280px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
          <h3>Your Orders</h3>
          <p>Track, return, or buy things again.</p>
          <a href="#" style="color: #007bff; font-weight: bold; text-decoration: none;">View Orders →</a>
          
        </div>
        <div style="background: white; padding: 1.5rem; border-radius: 10px; width: 280px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
          <h3>Login & Security</h3>
          <p>Edit login, name and mobile number.</p>
          <a href="#" style="color: #007bff; font-weight: bold; text-decoration: none;">Update Info →</a>
        </div>
        <div style="background: white; padding: 1.5rem; border-radius: 10px; width: 280px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
          <h3>Your Addresses</h3>
          <p>Manage your delivery addresses.</p>
          <a href="#" style="color: #007bff; font-weight: bold; text-decoration: none;">Edit Addresses →</a>
        </div>
        <div style="background: white; padding: 1.5rem; border-radius: 10px; width: 280px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
          <h3>Payment Options</h3>
          <p>Manage saved cards and UPI IDs.</p>
          <a href="#" style="color: #007bff; font-weight: bold; text-decoration: none;">Manage Payments →</a>
        </div>
        <div style="background: white; padding: 1.5rem; border-radius: 10px; width: 280px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
          <h3>Your Wishlist</h3>
          <p>View and manage your wishlist items.</p>
          <a href="#" style="color: #007bff; font-weight: bold; text-decoration: none;">Go to Wishlist →</a>
        </div>
        <div style="background: white; padding: 1.5rem; border-radius: 10px; width: 280px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
          <h3>Customer Support</h3>
          <p>Need help? We're here for you.</p>
          <a href="#" style="color: #007bff; font-weight: bold; text-decoration: none;">Contact Support →</a>
        </div>
      </div>
    </div>
  </section>
    
  <footer style="background: #343a40; color: #fff; padding: 2rem; text-align: center; margin-top: 4rem;">
    <p>&copy; 2025 Aurellia. All rights reserved.</p>
    <p>
      <a href="about.html" style="color: #ccc; margin: 0 1rem; text-decoration: none;">About</a>
      <a href="contact.html" style="color: #ccc; margin: 0 1rem; text-decoration: none;">Contact</a>
      <a href="shop.html" style="color: #ccc; margin: 0 1rem; text-decoration: none;">Shop</a>
    </p>
  </footer>
  
</html>
<?php endif; ?>
