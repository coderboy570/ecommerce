<?php
session_start();
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = $_SESSION['user'] ?? 'Guest';
$data = json_decode(file_get_contents("php://input"), true);

$cart = $data['cart'];
$name = $data['name'];
$email = $data['email'];
$address = $data['address'];
$total = $data['total'];
$date = date("Y-m-d H:i:s");

foreach ($cart as $item) {
    $stmt = $conn->prepare("INSERT INTO orders (username, product_id, product_name, price, quantity, image_url, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "sssdisd",
        $user,
        $item['id'],
        $item['name'],
        $item['price'],
        $item['quantity'],
        $item['img'],
        $date
    );
    $stmt->execute();
    $stmt->close();
}

echo "✅ Order saved to database!";
$conn->close();
?>
