<?php
$conn = new mysqli("localhost", "root", "", "ecommerce_db1");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);
$cart = json_decode($data["orderData"], true);
$payment_id = $data["razorpay_payment_id"];
$total = $data["total"];
$date = date("Y-m-d H:i:s");

foreach ($cart as $item) {
  $stmt = $conn->prepare("INSERT INTO orders (payment_id, product_id, product_name, price, quantity, image_url, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("sssdisd", $payment_id, $item['id'], $item['name'], $item['price'], $item['quantity'], $item['img'], $date);
  $stmt->execute();
  $stmt->close();
}

echo "✅ Payment and Order Saved!";
$conn->close();
?>
